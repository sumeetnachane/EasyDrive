package com.sumeet.DrivingSchool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DrivingSchoolApplicationTests {

	@Test
	void contextLoads() {
	}

}
