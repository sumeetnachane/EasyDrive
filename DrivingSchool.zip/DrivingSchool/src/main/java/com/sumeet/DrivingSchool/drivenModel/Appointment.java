package com.sumeet.DrivingSchool.drivenModel;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Appointment {
	
	private String name;
	@Id
	private String email;
	private String coursetype;
	private String cartype;
	private String message;
	public Appointment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Appointment(String name, String email, String coursetype, String cartype, String message) {
		super();
		this.name = name;
		this.email = email;
		this.coursetype = coursetype;
		this.cartype = cartype;
		this.message = message;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCoursetype() {
		return coursetype;
	}
	public void setCoursetype(String coursetype) {
		this.coursetype = coursetype;
	}
	public String getCartype() {
		return cartype;
	}
	public void setCartype(String cartype) {
		this.cartype = cartype;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "Appointment [name=" + name + ", email=" + email + ", coursetype=" + coursetype + ", cartype=" + cartype
				+ ", message=" + message + "]";
	}
	
	
	

}
