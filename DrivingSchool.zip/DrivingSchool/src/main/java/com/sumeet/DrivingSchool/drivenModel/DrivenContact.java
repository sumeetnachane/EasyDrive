package com.sumeet.DrivingSchool.drivenModel;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class DrivenContact {

	private String name;
	@Id
	private String email;
	private String number;
	private String message;
	public DrivenContact() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DrivenContact(String name, String email, String number, String message) {
		super();
		this.name = name;
		this.email = email;
		this.number = number;
		this.message = message;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "DrivenContact [name=" + name + ", email=" + email + ", number=" + number + ", message=" + message + "]";
	}
	

	
	
}
