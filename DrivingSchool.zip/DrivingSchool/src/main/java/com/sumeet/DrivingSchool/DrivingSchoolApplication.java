package com.sumeet.DrivingSchool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DrivingSchoolApplication {

	public static void main(String[] args) {
		SpringApplication.run(DrivingSchoolApplication.class, args);
		System.out.println("Hello dosto...");
	}

}
