package com.sumeet.DrivingSchool.drivenController;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sumeet.DrivingSchool.drivenModel.Appointment;
import com.sumeet.DrivingSchool.drivenModel.DrivenContact;
import com.sumeet.DrivingSchool.drivenModel.Login;
import com.sumeet.DrivingSchool.drivenModel.Newsletter;


@Controller
public class DrivenController {

	@Autowired
	SessionFactory sf;

	@RequestMapping("homepage")
	public String homePage() {
		return "index";
	}
	
	
	@RequestMapping("appointmentsave")
	public String appointmentSave(Appointment app) {

		Session ss = sf.openSession();
		Transaction tt = ss.beginTransaction();
		ss.persist(app);
		tt.commit();
		return "index";
	}
	
	@RequestMapping("newsletterpage")
	public String Newsletter(Newsletter news) {
		Session ss = sf.openSession();
		Transaction tt = ss.beginTransaction();
		ss.persist(news);
		tt.commit();
		return "index";
		
	}
	
	
	

	@RequestMapping("aboutpage")
	public String aboutPage() {
		return "about";
	}

	@RequestMapping("coursespage")
	public String coursesPage() {
		return "courses";
	}
	
	
	@RequestMapping("featurepage")
	public String featuresPage() {
		return "feature";
	}
	
	
	@RequestMapping("appointmentpage")
	public String appointmentPage() {
		return "appointment";
	}
	
	@RequestMapping("teampage")
	public String ourTeamPage() {
		return "team";
	}
	
	
	@RequestMapping("testimonialpage")
	public String testimonialPage() {
		return "testimonial";
	}
	
	@RequestMapping("404page")
	public String errorPage() {
		return "404";
		
	}

	@RequestMapping("contactpage")
	public String contactPage() {
		return "contact";
	}

	@RequestMapping("contactsave")
	public String contactSave(DrivenContact contact) {

		Session ss = sf.openSession();
		Transaction tt = ss.beginTransaction();
		ss.persist(contact);
		tt.commit();
		return "contact";

	}

	@RequestMapping("createaccountpage")
	public String createAccount() {
		return "createaccount";
	}

	@RequestMapping("createaccountsave")
	public String createAccountSave(Login login) {

		Session ss = sf.openSession();
		Transaction tt = ss.beginTransaction();
		ss.persist(login);
		tt.commit();
		return "createaccount";
	}

	@RequestMapping("userloginpage")
	public String userLogin() {
		return "userlogin";
	}

	@RequestMapping("userloginhome")
	public String userLoginHome(Login login) {
		Session ss = sf.openSession();
		Login dbLogin = ss.get(Login.class, login.getPassword());

		if (dbLogin != null) {
			if (dbLogin.equals(dbLogin)) {
				return "index";
			} else {
				return "userlogin";
			}
		} else {
			return "userlogin";
		}
	}

	@RequestMapping("adminloginpage")
	public String adminLogin() {
		return "adminlogin";
	}

	@RequestMapping("adminloginhome")
	public String adminLoginHome(Login login) {
		Session ss = sf.openSession();
		Login dbLogin = ss.get(Login.class, login.getPassword());

		if (dbLogin != null) {
			if (dbLogin.equals(dbLogin)) {
				return "adminindex";
			} else {
				return "adminlogin";
			}
		} else {
			return "adminlogin";
		}

	}
	
	@RequestMapping("adminshow")
	public String adminShow() {
		return "adminshow";
		
	}
}
